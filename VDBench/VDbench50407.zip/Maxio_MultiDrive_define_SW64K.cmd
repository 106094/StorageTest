echo off
echo **  Vdbench Multi-Storage Devices Stress Test 
echo **  Version 2.0 Date: 2013/4/11
echo **
Echo ** usage example :
echo **
echo ** SSDIO 5 50 3000 MySSD_results
echo ** use Storage Multi-Devices physicaldrive"1-255"
echo ** Apply max. Thread count/workload definition = 50
echo ** IO rate set = 3000 IOs per second
echo ** output directory name for results = MySSD_results
echo **
echo Test using DriveNum=%1 Threads=%2 IOrate=%3 results=%4
echo on
timeout 20
rem echo off
REM ==================================================
REM SSDIO Endurance Profile Example
REM ==================================================
set Drv=%1%
set T=%2%
set IO=iorate
set /A A1=%IO%*90
set /A A=%A1%/100
set /A B1=%IO%*80
set /A B=%B1%/100
set /A C1=%IO%*50
set /A C=%C1%/100
set /A D1=%IO%*10
set /A D=%D1%/100
set /A E=%IO%/100
set /A maxnum=%Drv%
REM ***************************************************************************
REM enduration time set by elapse time=1000h (hours)
REM set data errors to 10 Any greater then device testing should not continue
REM ***************************************************************************
REM
if /I %maxnum% gtr 254 (
goto END
)
echo * SSDIO Profile > ssdio.go
for /l %%a in (1,1,%maxnum%) do (
echo sd=sd%%a,lun=\\.\physicaldrive%%a,align=4k,threads=%T% >> ssdio.go
)
echo data_errors=1000
echo wd=wd1,sd=*,rdpct=0,seek=0,xfersize=(64k,100),range=(1,100),skew=100 >> ssdio.go
echo rd=SSD_Sustain,wd=wd*,iorate=curve,curve=(10-120,10),elapsed=10,interval=5 >> ssdio.go
REM echo Please Check these values are correct!
REM pause
call vdbench -f ssdio.go -m %maxnum% -o %4%_1
call vdbench -f ssdio.go -m %maxnum% -o %4%_2
call vdbench -f ssdio.go -m %maxnum% -o %4%_3
call vdbench -f ssdio.go -m %maxnum% -o %4%_4
call vdbench -f ssdio.go -m %maxnum% -o %4%_5

:END
echo Notice: The drive numbers must less than or equal 254.
exit /b 5
