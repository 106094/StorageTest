cd %~dp0

call Maxio_MultiDrive_define_RR4K.cmd 1 128 max Random_Read_4k_128_thread
timeout 20
call Maxio_MultiDrive_define_RW4K.cmd 1 64 max Random_Write_4k_64_thread
timeout 20
call Maxio_MultiDrive_define_SR64K.cmd 1 16 max Sequential_Read_64k_16_thread
timeout 20
call Maxio_MultiDrive_define_SW64K.cmd 1 8 max Sequential_Write_64k_8_thread
timeout 20

pause
