* SSDIO Profile 
sd=sd1,lun=\\.\physicaldrive1,align=4k,threads=128 
wd=wd1,sd=*,rdpct=100,seek=100,xfersize=(4k,100),range=(1,100),skew=100 
rd=SSD_Sustain,wd=wd*,iorate=curve,curve=(10-120,10),elapsed=10,interval=5 
